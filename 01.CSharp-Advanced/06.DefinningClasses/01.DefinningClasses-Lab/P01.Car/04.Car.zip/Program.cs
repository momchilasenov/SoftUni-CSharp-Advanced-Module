﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Car car = new Car();
            //car.Make = "Audi";
            //car.Model = "A4";
            //car.Year = 1999;
            //car.FuelConsumption = 8;
            //car.FuelQuantity = 40;

            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model} \nYear: {car.Year}");
            //Console.WriteLine(car.WhoAmI());

            //car.Drive(20);
            //car.Drive(30);

            Engine v12 = new Engine(350, 1200);
            Tire[] tires = new Tire[]
            {
                new Tire(2018, 2.3),
                new Tire(2013, 2.2),
                new Tire(2015, 2.5),
                new Tire(2014, 2.4)
            };

            Car newCar = new Car("BMW", "M4", 2020, 200, 20, v12, tires);
            Console.WriteLine(newCar.Engine.CubicCapacity);
        }
    }
}
