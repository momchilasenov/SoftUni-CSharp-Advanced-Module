﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person pesho = new Person() { Name = "Pesho", Age = 24 };
            Person misho = new Person() { Name = "Misho", Age = 25 };
        }
    }
}
