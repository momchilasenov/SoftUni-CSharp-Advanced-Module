﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "Audi";
            car.Model = "A4";
            car.Year = 1999;
            car.FuelConsumption = 8;
            car.FuelQuantity = 40;

            Console.WriteLine($"Make: {car.Make}\nModel: {car.Model} \nYear: {car.Year}");
            Console.WriteLine(car.WhoAmI());

            car.Drive(20);
            car.Drive(30);
        }
    }
}
